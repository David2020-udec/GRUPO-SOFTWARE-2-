<?php

include 'includes/header.php';

?>
    <!-- Script para el flexslider-->
<script type="text/javascript" charset="utf-8">
    $(window).load
    (function() 
    {
      $('.flexslider').flexslider(
        {
          touch:true,
          pauseOnAction: false,
          PauseOnHover: false,
        }
        );
    }
    );
</script>

<body>
<header>
  <div class="container">
     <h4 class="display-3">Centro Academico Deportivo (CAD)</h4>

  </div>
 
</header>>


<main class="container p-1">

	<div class="row">
        <div class="col-md-12">
                <center>
                  <div class="flexslider">
                    <ul class="slides">
                      <li>
                        <img src="imagenes/I1.png">
                        <section class="flex-caption">
                          <p>.</p>
                        </section>
                      </li>
                      <li>
                        <img src="imagenes/I2.png">
                        <section class="flex-caption">
                          <p>.</p>
                        </section>
                      </li>
                      <li>
                        <img src="imagenes/I3.png">
                        <section class="flex-caption">
                          <p>.</p>
                        </section>
                      </li>
                      <li>
                        <img src="imagenes/I4.png">
                        <section class="flex-caption">
                          <p>.</p>
                        </section>
                      </li>
                      <li>
                        <img src="imagenes/I5.png">
                        <section class="flex-caption">
                          <p>.</p>
                        </section>
                      </li>
                      <li>
                        <img src="imagenes/I6.png">
                        <section class="flex-caption">
                          <p>.</p>
                        </section>
                      </li>
                      <li>
                        <img src="imagenes/I7.png">
                        <section class="flex-caption">
                          <p>.</p>
                        </section>
                      </li>
                    </ul>
                  </div>
                </center>
        </div>
    </div>
</main>
</body>
</html>
